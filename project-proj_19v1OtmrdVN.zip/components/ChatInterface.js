function ChatInterface() {
    try {
        const [messages, setMessages] = React.useState([]);
        const [input, setInput] = React.useState('');
        const [isLoading, setIsLoading] = React.useState(false);
        const messagesEndRef = React.useRef(null);

        const scrollToBottom = () => {
            messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
        };

        React.useEffect(() => {
            scrollToBottom();
        }, [messages]);

        const handleSubmit = async (e) => {
            e.preventDefault();
            if (!input.trim()) return;

            const userMessage = input.trim();
            setMessages(prev => [...prev, { text: userMessage, type: 'user' }]);
            setInput('');
            setIsLoading(true);

            try {
                const response = await medicineAgent(userMessage);
                setMessages(prev => [...prev, { text: response, type: 'bot' }]);
            } catch (error) {
                console.error('Failed to get response:', error);
                setMessages(prev => [...prev, { 
                    text: "I'm sorry, I couldn't process your request. Please try again.", 
                    type: 'bot' 
                }]);
            } finally {
                setIsLoading(false);
            }
        };

        return (
            <div data-name="chat-interface" className="chat-container max-w-2xl mx-auto rounded-lg shadow-lg overflow-hidden">
                <div data-name="chat-header" className="bg-blue-600 p-4 text-white">
                    <h2 className="text-lg font-semibold">AI Medicine Assistant</h2>
                </div>
                
                <div data-name="chat-messages" className="chat-messages p-4 h-96">
                    {messages.map((msg, index) => (
                        <ChatMessage key={index} message={msg.text} type={msg.type} />
                    ))}
                    {isLoading && (
                        <div data-name="loading-indicator" className="bot-message message p-3">
                            <p className="text-sm">Thinking...</p>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
                
                <form data-name="chat-form" onSubmit={handleSubmit} className="chat-input p-4 bg-white">
                    <div className="flex gap-2">
                        <input
                            data-name="chat-input"
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="Ask about medicine alternatives..."
                            className="flex-1 p-2 border rounded-lg focus:outline-none focus:border-blue-500"
                        />
                        <button
                            data-name="send-button"
                            type="submit"
                            disabled={isLoading}
                            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-blue-400"
                        >
                            <i className="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </form>
            </div>
        );
    } catch (error) {
        console.error('ChatInterface component error:', error);
        reportError(error);
        return null;
    }
}
