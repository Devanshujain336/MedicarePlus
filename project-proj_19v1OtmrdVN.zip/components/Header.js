function Header() {
    try {
        return (
            <header data-name="header" className="header p-4 text-white">
                <div data-name="header-content" className="container mx-auto flex items-center justify-between">
                    <div data-name="logo-container" className="flex items-center space-x-2">
                        <i className="fas fa-pills text-2xl"></i>
                        <h1 className="text-xl font-bold">Medicine Finder</h1>
                    </div>
                    <nav data-name="navigation" className="hidden md:flex space-x-6">
                        <a href="#" className="hover:text-blue-200 transition-colors">Home</a>
                        <a href="#" className="hover:text-blue-200 transition-colors">About</a>
                        <a href="#" className="hover:text-blue-200 transition-colors">Contact</a>
                    </nav>
                </div>
            </header>
        );
    } catch (error) {
        console.error('Header component error:', error);
        reportError(error);
        return null;
    }
}
