function ChatMessage({ message, type }) {
    try {
        const messageClass = type === 'user' ? 'user-message ml-auto' : 'bot-message';
        
        return (
            <div data-name="chat-message" className={`message p-3 ${messageClass}`}>
                <p data-name="message-text" className="text-sm">{message}</p>
            </div>
        );
    } catch (error) {
        console.error('ChatMessage component error:', error);
        reportError(error);
        return null;
    }
}
