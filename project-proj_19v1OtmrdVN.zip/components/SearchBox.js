function SearchBox({ onSearch }) {
    try {
        const [searchTerm, setSearchTerm] = React.useState('');

        const handleSubmit = (e) => {
            e.preventDefault();
            if (searchTerm.trim()) {
                onSearch(searchTerm);
            }
        };

        return (
            <div data-name="search-section" className="search-container p-6 rounded-lg mx-4 my-6">
                <form data-name="search-form" onSubmit={handleSubmit} className="max-w-2xl mx-auto">
                    <div data-name="search-input-container" className="flex flex-col md:flex-row gap-4">
                        <input
                            data-name="search-input"
                            type="text"
                            placeholder="Enter medicine name or active ingredients..."
                            className="search-input flex-1 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        <button
                            data-name="search-button"
                            type="submit"
                            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                        >
                            Search
                        </button>
                    </div>
                </form>
            </div>
        );
    } catch (error) {
        console.error('SearchBox component error:', error);
        reportError(error);
        return null;
    }
}
